import random
import operator
import sys
import unittest
from matplotlib import pyplot as plt
import matplotlib.image as img

def replace(my_list, X, Y):
       while X in my_list:
         my_list.insert(my_list.index(X), Y)
         my_list.pop(my_list.index(X))

def rgbred(img):
    lista=[]
    lista=img[0]
    lista2=[]
    lista2=img[0][0]
    lista3=[]
    for x in range(len(img)):
        for y in range(len(lista)):
           lista3.append(img[x][y][0])
    return lista3

def rgbgreen(img):
    lista=[]
    lista=img[0]
    lista2=[]
    lista2=img[0][0]
    lista3=[]
    for x in range(len(img)):
        for y in range(len(lista)):
           lista3.append(img[x][y][1])
    return lista3

def rgbblue(img):
    lista=[]
    lista=img[0]
    lista2=[]
    lista2=img[0][0]
    lista3=[]
    for x in range(len(img)):
        for y in range(len(lista)):
           lista3.append(img[x][y][2])
    return lista3

def rgbhistr(img):
    r=rgbred(img)
    lista5=[]
    for x in range(0,256):
      lista5.append(x)
    plt.hist(r, bins=lista5, color='red')
    return plt.show()

def rgbhistg(img):
    g=rgbgreen(img)
    lista5=[]
    for x in range(0,256):
      lista5.append(x)
    plt.hist(g, bins=lista5, color='green')
    return plt.show()

def rgbhistb(img):
    b=rgbblue(img)
    lista5=[]
    for x in range(0,256):
      lista5.append(x)
    plt.hist(b, bins=lista5, color='blue')
    return plt.show()

def smithal(chain1, chain2, mb, mp, gp):
    Mat=Matrix.swmat(chain1, chain2, mb, mp, gp)
    tb=list(reversed(Matrix.swtrace(Mat)))
    st1=[]
    st2=[]
    for x in range(len(tb)-1):
        opa=[tb[x][0]+1,tb[x][1]+1]
        opb=[tb[x][0],tb[x][1]+1]
        opc=[tb[x][0]+1,tb[x][1]]
        if(tb[x+1]==opa):
            st1.append(chain2[tb[x+1][1]-1])
            st2.append(chain1[tb[x+1][0]-1])
        if(tb[x+1]==opc):
            st1.append("-")
            st2.append(chain1[tb[x+1][0]-1])

        if(tb[x+1]==opb):
            st2.append("-")
            st1.append(chain2[tb[x+1][1]-1])

    return str(st1)+"\n"+str(st2)

class Matrix(object): #declara la clase


    def __init__(self, m, n, init=True): #el constructor de la clase matriz
        if init:
            self.rows = [[0]*n for x in range(m)]
        else:
            self.rows = []
        self.m = m
        self.n = n

    def __getitem__(self, idx): #escribe en una lista la fila que el usuario desee de una matriz determinada
        return self.rows[idx]

    def __setitem__(self, idx, item): #escribe una fila en una matriz determinada (en caso de que ya exista dicha fila en la matriz, se le cae encima)
        self.rows[idx] = item

    def __str__(self):
        s='\n'.join([' '.join([str(item) for item in row]) for row in self.rows])
        return s + '\n'

    def getRank(self): #devuelve el rango de la matriz
        return (self.m, self.n)

    def transpose(self): #transpone la matriz original

        self.m, self.n = self.n, self.m
        self.rows = [list(item) for item in zip(*self.rows)]

    def getTranspose(self): #retorna una matriz idendica a la transpuesta de la matriz original sin cambiar esta ultima

        m, n = self.n, self.m
        mat = Matrix(m, n)
        mat.rows =  [list(item) for item in zip(*self.rows)]

        return mat

    def mat2array(self): #convierte una matriz en una lista de numeros
        array=[]
        for x in range(self.m):
            fila = Matrix.__getitem__(self, x)
            for y in range(len(fila)):
                array.append(fila[y])
        return array

    def mathist(self, bins): #crea un histograma a partir de una matriz. El usuario inserta los binns que desea para el histograma
        matgraf = Matrix.mat2array(self)
        plt.hist(matgraf, bins=bins)
        return plt.show()

    def rowmult(self, r, k): #multiplica una fila en la matriz por un valor dado y devuelve una matriz sin modificar la original
      if r>=self.m:
       return "El numero dado excede el numero de filas"
      else:
          fila = Matrix.__getitem__(self,r)
          filanueva =[]
          for x in range(len(fila)):
            filanueva.append(fila[x]*k)
          m, n = self.m, self.n
          mat = Matrix(m, n)
          mat.rows =  list(self.rows)
          Matrix.__setitem__(mat,r,filanueva)
          return mat

    def rowmulti(self, r, k): #multiplica una fila en la matriz por un valor dado y devuelve una matriz sin modificar la original
      if r>=self.m:
       return "El numero dado excede el numero de filas"
      else:
          fila = Matrix.__getitem__(self,r)
          filanueva =[]
          for x in range(len(fila)):
            filanueva.append(fila[x]*k)
          Matrix.__setitem__(self,r,filanueva)
          return self

    def rowunit(self, i): #divide la fila de una matriz por el primer termino en esta distinto de cero y devuelve una matriz sin modificar la original
        fila = Matrix.__getitem__(self,i)
        r=0
        while fila[r]==0:
            r+=1
            if r>=len(fila):
                break
        if r>=len(fila):
                return self
        else:
          inv = (1.0/fila[r])
          mat = Matrix.rowmult(self, i, inv)
          return mat

    def rowuniti(self, i): #divide la fila de una matriz por el primer termino en esta distinto de cero y devuelve una matriz sin modificar la original
        fila = Matrix.__getitem__(self,i)
        r=0
        while fila[r]==0:
            r+=1
            if r>=len(fila):
                break
        if r>=len(fila):
                return self
        else:
          inv = (1.0/fila[r])
          mat = Matrix.rowmulti(self, i, inv)
          return self

    def rowunitinv(self, mat, i):
        fila = Matrix.__getitem__(mat,i)
        r=0
        while fila[r]==0:
            r+=1
            if r>=len(fila):
                break
        if r>=len(fila):
                return self
        else:
          inv = (1.0/fila[r])
          mat = Matrix.rowmulti(self, i, inv)
          return self

    def matuniti(self): #divide todas las filas de una matriz dada por el primer termino distinto de cero de cada fila. Modifica la original
        for x in range(self.m):
            Matrix.rowuniti(self, x)
        return self

    def matunitinv(self, mat):
        m, n = mat.m, mat.n
        mat2 = Matrix(m, n)
        mat2.rows =  list(mat.rows)
        for x in range(self.m):
            Matrix.rowunitinv(self, mat, x)
        return self

    def matunit(self): #divide todas las filas de una matriz dada por el primer termino distinto de cero de cada fila. No modifica la original
        m, n = self.m, self.n
        mat = Matrix(m, n)
        mat.rows =  list(self.rows)
        for x in range(self.m):
            Matrix.rowuniti(mat, x)
        return mat

    def rowsum(self, r1, r2, k): #suma una fila de la matriz multiplicada por un valor dado a otra fila indicada, retorna una matriz y no modifica a la original
      if r1>=self.m or r2>=self.m :
       return "Uno de los numeros dados excede el numero de filas"
      else:
          fila1= Matrix.__getitem__(self,r1)
          fila2= Matrix.__getitem__(self,r2)
          filanueva =[]
          for x in range(len(fila1)):
            filanueva.append(fila1[x]+k*fila2[x])
          m, n = self.m, self.n
          mat = Matrix(m, n)
          mat.rows =  list(self.rows)
          Matrix.__setitem__(mat,r1,filanueva)
          return mat

    def rowsumi(self, r1, r2, k): #suma una fila de la matriz multiplicada por un valor dado a otra fila indicada, retorna una matriz y modifica a la original
      if r1>=self.m or r2>=self.m :
       return "Uno de los numeros dados excede el numero de filas"
      else:
          fila1= Matrix.__getitem__(self,r1)
          fila2= Matrix.__getitem__(self,r2)
          filanueva =[]
          for x in range(len(fila1)):
            filanueva.append(fila1[x]+k*fila2[x])
          Matrix.__setitem__(self,r1,filanueva)
          return self

    def changerow(self, r1, r2): #retorna una matriz que es igual a la original, con las filas indicadas cambiadas
        fila1= Matrix.__getitem__(self,r1)
        fila2= Matrix.__getitem__(self,r2)
        m, n = self.m, self.n
        mat = Matrix(m, n)
        mat.rows =  list(self.rows)
        Matrix.__setitem__(mat,r1,fila2)
        Matrix.__setitem__(mat,r2,fila1)
        return mat

    def changerowi(self, r1, r2): #cambia las filas indicadas de una matriz, modificandola
        fila1= Matrix.__getitem__(self,r1)
        fila2= Matrix.__getitem__(self,r2)
        Matrix.__setitem__(self,r1,fila2)
        Matrix.__setitem__(self,r2,fila1)
        return self

    def returnpos(self, m, n): #retorna el valor de una posicion indicada en la matriz
        if m>=self.m or n>=self.n:
          return "Las posiciones dadas exceden las dimensiones de la matriz"
        else:
           fila = Matrix.__getitem__(self, m)
           valpos = fila[n]
           return valpos

    def quanzer(self, m): #retorna la cantidad de ceros que hay en una fila determinada
        fila = Matrix.__getitem__(self, m)
        q=0
        p=0.0
        for x in range(len(fila)):
            if fila[x]!=0:
                break
            elif fila[x]==0 or fila[x]==0.0:
                q+=1
        return q

    def order(self): #devuelve una matriz que posee las filas de la matriz original ordenadas de menor a mayor cantidad de ceros de arriba para abajo sin modificar la original
        m, n = self.m, self.n
        mat = Matrix(m, n)
        mat.rows =  list(self.rows)
        i=0
        rang=(self.m)
        max=0
        for x in range(rang):
          for y in range(x, rang):
            if Matrix.quanzer(mat, x)>Matrix.quanzer(mat, y):
                max=y
                Matrix.changerowi(mat, x, max)
        return mat

    def orderi(self): #devuelve una matriz que posee las filas de la matriz original ordenadas de menor a mayor cantidad de ceros de arriba para abajo sin modificar la original
        i=0
        rang=(self.m)
        max=0
        for x in range(rang):
          for y in range(x, rang):
            if Matrix.quanzer(self, x)>Matrix.quanzer(self, y):
                max=y
                Matrix.changerowi(self, x, max)
        return self

    def orderinv(self, mat): #submetodo utilizado para el calculo de inversas
        m, n = mat.m, mat.n
        mat2 = Matrix(m, n)
        mat2.rows =  list(mat.rows)
        i=0
        rang=(mat2.m)
        max=0
        for x in range(rang):
          for y in range(x, rang):
            if Matrix.quanzer(mat2, x)>Matrix.quanzer(mat2, y):
                max=y
                Matrix.changerowi(self, x, max)
                Matrix.changerowi(mat2, x, max)
        return self

    def rowuneg(self, i):  #si el primer termino de una fila dada es -1, se multiplica toda la fila por -1.
        fila = Matrix.__getitem__(self,i)
        r=0
        while fila[r]==0:
            r+=1
            if r>=len(fila):
                break
        if r>=len(fila):
                return self
        elif fila[r]<0:
          mat = Matrix.rowmult(self, i, -1)
          return mat
        else:
            return self

    def trianmat(self): #devuelve la matriz triangular inferior equivalente de una matriz dada, sin modificar la original
        m, n = self.m, self.n
        mat = Matrix(m, n)
        mat.rows =  list(self.rows)
        Matrix.orderi(mat)
        Matrix.matuniti(mat)
        j=0
        fila = Matrix.__getitem__(mat,0)
        filanueva =[]
        for x in range(len(fila)):
          filanueva.append(0)
        for x in range(self.m-1):
            for y in range(x+1, self.m):
                v = Matrix.returnpos(mat, y, j)
                e = Matrix.returnpos(mat, x, j)
                while e==0:
                  e = Matrix.returnpos(mat, x, j)
                  j+=1
                  if j>=self.n:
                    j+=-1
                    break
                v = Matrix.returnpos(mat, y, j)
                e = Matrix.returnpos(mat, x, j)
                if v!=0 and Matrix.__getitem__(mat, y)!=filanueva:
                  Matrix.rowsumi(mat, y, x, -v)
            Matrix.orderi(mat)
            Matrix.matuniti(mat)
            if j<self.n:
               j+=1
        return mat

    def send2last(self,r): #devuelve una matriz igual a la matriz dada, enviando la fila indicada a la ultima posicion. No modifica la original
        m, n = self.m, self.n
        mat = Matrix(m, n)
        mat.rows =  list(self.rows)
        for x in range(r, self.m-1):
          Matrix.changerowi(mat,x,x+1)
        return mat

    def send2lasti(self,r): #envia una fila de una matriz a la ultima posicion
        for x in range(r, self.m-1):
          Matrix.changerowi(self,x,x+1)
        return self

    def remrow(self, r): #entrega una matriz igual a la matriz dada removiendo una fila de esta, sin modificar la original
        if r>=self.m:
          return "Excede el numero de filas"
        else:
            m, n = self.m-1, self.n
            mat = Matrix(m, n)
            r, t = self.m, self.n
            mat2 = Matrix(r, t)
            mat2.rows =  list(self.rows)
            Matrix.send2lasti(mat2, r)
            for x in range(0,self.m-1):
              Matrix.__setitem__(mat,x,Matrix.__getitem__(mat2, x))
            return mat

    def remrowi(self, r): #remueve una fila de una matriz dada
        if r>=self.m:
          return "Excede el numero de filas"
        else:
            m, n = self.m-1, self.n
            mat = Matrix(m, n)
            r, t = self.m, self.n
            mat2 = Matrix(r, t)
            mat2.rows =  list(self.rows)
            Matrix.send2lasti(mat2, r)
            for x in range(0,self.m-1):
              Matrix.__setitem__(mat,x,Matrix.__getitem__(mat2, x))
            self.rows=mat.rows
            return self


    def rem0rows(self): #devuelve una matriz igual a matriz dada removiendole las filas de ceros, no modifica a la original
        fila = Matrix.__getitem__(self,0)
        filanueva =[]
        for x in range(len(fila)):
          filanueva.append(0)
        rang=self.m
        lista=[]
        for x in range(rang):
          if Matrix.__getitem__(self,x)==filanueva:
            lista.append(x)
        m, n = self.m, self.n
        mat = Matrix(m, n)
        mat.rows=self.rows
        for x in reversed(range(len(lista))):
            mat = Matrix.remrow(mat, lista[x])
        return mat

    def rem0rowsi(self): #remueve todas las filas de ceros de una matriz dada
        mat = Matrix.rem0rows(self)
        self.m=mat.m
        self.n=mat.n
        self.rows=mat.rows
        return self

    def trianmati(self): #convierte una matriz en su equivalente triangular inferior
        Matrix.orderi(self)
        Matrix.matuniti(self)
        j=0
        fila = Matrix.__getitem__(self,0)
        filanueva =[]
        for x in range(len(fila)):
          filanueva.append(0)
        for x in range(self.m-1):
            for y in range(x+1, self.m):
                v = Matrix.returnpos(self, y, j)
                e = Matrix.returnpos(self, x, j)
                while e==0:
                  e = Matrix.returnpos(self, x, j)
                  j+=1
                  if j>=self.n-1:
                    j+=-1
                    break
                v = Matrix.returnpos(self, y, j)
                e = Matrix.returnpos(self, x, j)
                if v!=0 and Matrix.__getitem__(self, y)!=filanueva:
                  Matrix.rowsumi(self, y, x, -v)
            Matrix.orderi(self)
            Matrix.matuniti(self)
            if j<self.n-1:
               j+=1
        return self

    def gaussjordan(self): #reduce un sistema de ecuaciones dado en forma de matriz
        m, n = self.m, self.n
        mat2 = Matrix(m, n)
        mat2.rows =  list(self.rows)
        mat = Matrix.rem0rowsi(mat2)
        Matrix.trianmati(mat)
        j=1
        fila = Matrix.__getitem__(mat,0)
        filanueva =[]
        for x in range(len(fila)):
          filanueva.append(0)
        for x in range(1, mat.m):
            for y in range(x-1,-1, -1):
                v = Matrix.returnpos(mat, y, j)
                e = Matrix.returnpos(mat, x, j)
                while e==0:
                  e = Matrix.returnpos(mat, x, j)
                  j+=1
                  if j>=self.n-1:
                    j+=-1
                    break
                if v!=0:
                  Matrix.rowsumi(mat, y, x, -v)
            Matrix.matuniti(mat)

            if j<mat.n-1:
              j+=1
        Matrix.orderi(mat)
        Matrix.rem0rowsi(mat)
        return mat

    def inv(self): #calcula la inversa de una matriz cuadrada
        fila = Matrix.__getitem__(self,0)
        filanueva =[]
        for x in range(len(fila)):
          filanueva.append(0)
        matdef=Matrix.trianmat(self)
        if Matrix.__getitem__(matdef, self.m-1)==filanueva or self.m != self.n:
            return "La matriz dada no tiene inversa"
        else:
            m, n = self.m, self.n
            mat2 = Matrix(m, n)
            mat2.rows =  list(self.rows)
            mat = Matrix.rem0rowsi(mat2)
            id = Matrix.trianmatinv(mat)
            Matrix.trianmati(mat)
            j=1
            fila = Matrix.__getitem__(mat,0)
            filanueva =[]
            for x in range(len(fila)):
              filanueva.append(0)
            for x in range(1, mat.m):
                for y in range(x-1,-1, -1):
                    v = Matrix.returnpos(mat, y, j)
                    e = Matrix.returnpos(mat, x, j)
                    while e==0:
                      e = Matrix.returnpos(mat, x, j)
                      j+=1
                      if j>=self.n-1:
                        j+=-1
                        break
                    if v!=0:
                      Matrix.rowsumi(id, y, x, -v)
                      Matrix.rowsumi(mat, y, x, -v)
                Matrix.matuniti(mat)

                if j<mat.n-1:
                  j+=1
            Matrix.orderinv(id, mat)
            Matrix.orderi(mat)
            Matrix.rem0rowsi(mat)
            return id

    def conjsol(self): #devuelve un string con el conjunto solucion de un sistema entregado en forma de matriz. Si el sistema no posee solucion, se devuelve un string indicando esta situacion
        mat=Matrix.gaussjordan(self)
        filanueva =[]
        fila = Matrix.__getitem__(mat,mat.m-1)
        for x in range(len(fila)):
          filanueva.append(0)
        filanueva[-1]=1
        if fila==filanueva:
            return "El sistema no tiene solucion"
        else:
            sol=""
            i=0
            for x in range(mat.m):
                for y in range(mat.n-1):
                    if Matrix.returnpos(mat,x,y)==1 and i==0:
                        sol+="x"+str(x+1)+" = "+str(Matrix.returnpos(mat,x,mat.n-1))
                        i=1
                    elif i==1 and Matrix.returnpos(mat,x,y)<0:
                      sol+=" + "+str(-1*Matrix.returnpos(mat,x,y))+"x"+str(y+1)
                    elif i==1 and Matrix.returnpos(mat,x,y)>0:
                      sol+=" - "+str(Matrix.returnpos(mat,x,y))+"x"+str(y+1)
                sol+="\n"
                i=0
        return sol

    def trianmatinv(self): #submetodo para calculo de inversas
        m, n = self.m, self.n
        mat = Matrix(m, n)
        mat.rows =  list(self.rows)
        id = Matrix.makeId(self.m)
        Matrix.orderinv(id, mat)
        Matrix.orderi(mat)
        Matrix.matunitinv(id, mat)
        Matrix.matuniti(mat)
        j=0
        fila = Matrix.__getitem__(mat,0)
        filanueva =[]
        for x in range(len(fila)):
          filanueva.append(0)
        for x in range(mat.m-1):
            for y in range(x+1, self.m):
                v = Matrix.returnpos(mat, y, j)
                e = Matrix.returnpos(mat, x, j)
                while e==0:
                  e = Matrix.returnpos(mat, x, j)
                  j+=1
                  if j>=mat.n-1:
                    j+=-1
                    break
                v = Matrix.returnpos(mat, y, j)
                e = Matrix.returnpos(mat, x, j)
                if v!=0 and Matrix.__getitem__(mat, y)!=filanueva:
                  Matrix.rowsumi(id, y, x, -v)
                  Matrix.rowsumi(mat, y, x, -v)

            Matrix.orderinv(id, mat)
            Matrix.orderi(mat)
            Matrix.matunitinv(id, mat)
            Matrix.matuniti(mat)
            if j<mat.n-1:
               j+=1
        return id

    def __add__(self, mat): #operacion de suma de matrices usando sobrecarga de operadores

        if self.getRank() != mat.getRank():
            return "Las matrices no se pueden sumar"

        ret = Matrix(self.m, self.n)

        for x in range(self.m):
            row = [sum(item) for item in zip(self.rows[x], mat[x])]
            ret[x] = row

        return ret

    def __mul__(self, mat): #operacion de multiplicacion de matrices usando sobrecarga de operadores
        if isinstance(mat, int) is True or isinstance(mat, float) is True:
            m, n = self.m, self.n
            mat2 = Matrix(m, n)
            mat2.rows =  list(self.rows)
            for x in range(self.m):
                Matrix.rowmulti(mat2, x, mat)
            return mat2

        else:
            matm, matn = mat.getRank()

            if (self.n != matm):
                return "Las matrices no son multiplicables"

            mat_t = mat.getTranspose()
            mulmat = Matrix(self.m, matn)

            for x in range(self.m):
                for y in range(mat_t.m):
                    mulmat[x][y] = sum([item[0]*item[1] for item in zip(self.rows[x], mat_t[y])])

            return mulmat

    def __rmul__(self, mat):
        return self*mat

    def maxleft(self, m, n, gp):
        max=0;
        j=n-1;
        k=0
        while(j>=0):
            if(max<Matrix.returnpos(self, m, j)):
                max=Matrix.returnpos(self, m, j)
                k=j
            j=j-1
        max=max-gp
        if(max<=0):
            return 0
        else:
            return max


    def maxup(self, m, n, gp):
        max=0;
        i=m-1;
        k=0
        while(i>=0):
            if(max<Matrix.returnpos(self, i, n)):
                max=Matrix.returnpos(self, i, n)
                k=i
            i=i-1
        max=max-gp
        if(max<=0):
            return 0
        else:
            return max

    def diagval(self, m, n, chain1, chain2, mb, mp):
        st1= [0]+chain1
        st2= [0]+chain2
        if(st1[m]==st2[n]):
            diag=Matrix.returnpos(self, m-1, n-1)+mb
        elif(st1[m]!=st2[n]):
            if(Matrix.returnpos(self, m-1, n-1)-mp>0):
                diag=Matrix.returnpos(self, m-1, n-1)-mp
            elif(Matrix.returnpos(self, m-1, n-1)-mp<=0):
                diag=0
        return diag

    def hmax(self, m, n , chain1, chain2, mb, mp, gp):
        hmax=[]
        hmax.append(Matrix.diagval(self, m, n, chain1, chain2, mb, mp))
        hmax.append(Matrix.maxup(self, m, n, gp))
        hmax.append(Matrix.maxleft(self, m, n, gp))
        hmax.sort()
        return hmax[-1]

    def maxrowval(self,i):
        vals = list(Matrix.__getitem__(self, i))
        vals.sort()
        return vals[-1]

    def maxmatval(self):
       max = 0
       for i in range(self.m):
          if(max<=Matrix.maxrowval(self, i)):
             max = Matrix.maxrowval(self, i)
             r=i
             for j in range(self.n):
                if(Matrix.returnpos(self,i,j)==Matrix.maxrowval(self, i)):
                    c=j
       val=[r,c]
       return val

    def hmaxinv(self, m, n):

        up=Matrix.returnpos(self, m, n-1)
        left=Matrix.returnpos(self, m-1, n)
        diag=Matrix.returnpos(self, m-1, n-1)
        val = []
        if(self.m<=m or self.n<=n):
            return "Las posiciones dadan exceden las dimensiones de la matriz"
        if(diag==up and diag==left):
            return [m-1,n-1]
        if(diag==up and diag>left):
            return [m-1,n-1]
        if(diag==left and diag>up):
            return [m-1,n-1]
        else:
            val.extend((diag,up,left))
            val.sort()
            if(val[-1]==up):
                return [m,n-1]
            if(val[-1]==left):
                return [m-1,n]
            elif(val[-1]==diag):
                return [m-1,n-1]

    def swtrace(self):
        pos=Matrix.maxmatval(self)
        traceback=[]
        while(Matrix.returnpos(self, pos[0], pos[1])!=0):
            traceback.append(pos)
            pos=Matrix.hmaxinv(self, pos[0], pos[1])
        traceback.append([0,0])
        return traceback




    @classmethod
    def swmat(cls, chain1, chain2, mb, mp, gp):
        mat = Matrix.makeZero(len(chain1)+1, len(chain2)+1)
        for i in range(1, len(chain2)+1, 1):
            for j in range(1, len(chain1)+1, 1):
                mat[i][j]=Matrix.hmax(mat, i, j, chain1, chain2, mb, mp, gp)
        return mat

    @classmethod
    def TextToString(self,name):
        cadena=[]
        archi=open(name,'r')
        linea=archi.readline()
        while linea!="":
            #print linea
            cadena=list(linea)
            linea=archi.readline()
        archi.close()
        cadena.pop()
        print cadena
        return cadena

    @classmethod
    def _makeMatrix(cls, rows):

        m = len(rows)
        n = len(rows[0])
        if any([len(row) != n for row in rows[1:]]):
            return "Hay un error de dimensiones"
        mat = Matrix(m,n, init=False)
        mat.rows = rows

        return mat

    @classmethod
    def makeRandom(cls, m, n, low=0, high=10): #genera matriz aleatoria

        obj = Matrix(m, n, init=False)
        for x in range(m):
            obj.rows.append([random.randrange(low, high) for i in range(obj.n)])

        return obj

    @classmethod
    def makeId(cls, m):

        rows = [[0]*m for x in range(m)]
        idx = 0

        for row in rows:
            row[idx] = 1
            idx += 1

        return cls.fromList(rows)

    @classmethod
    def readGrid(cls, fname): #lee matriz de archivo de texto plano (solo una matriz por archivo, con caracteres separados un espacio y filas separadas por un cambio de linea)

        rows = []
        for line in open(fname).readlines():
            row = [int(x) for x in line.split()]
            rows.append(row)

        return cls._makeMatrix(rows)

    @classmethod
    def fromList(cls, listoflists): #metodo que crea una matriz a partir de una lista de listas
        rows = listoflists[:]
        return cls._makeMatrix(rows)

    @classmethod
    def makeZero(cls, m, n):        #metodo que hace una matriz m*n de ceros
        rows = [[0]*n for x in range(m)]
        return cls.fromList(rows)
#lectura desde archivos de las cadenas
st2=Matrix.TextToString('chain5.txt')
st=Matrix.TextToString('chain6.txt')

lista =[[0,0,0,0],[1,0,0,0],[2,1,1,8]]
lista2 =[[1,2,2],[0,1,5],[1,0,3]]
lista3 =[[1,2,2,3,4],[0,1,5,6,7]]
string1=["A","C","A","C","A","C","T","A"]
string2=["A","G","C","A","C","A","C","A"]
#st=["A","A","U","G","C","C","A","U","U","G","A","C","G"]
#st2=["C","A","G","C","C","U","C","G","C","U","U","A","G"]
m = Matrix.fromList(lista)
m2 = Matrix.fromList(lista)
m3 = Matrix.fromList(lista2)
m4 = Matrix.fromList(lista3)

m = Matrix.swmat(st2, st, 2, 1, 1)

print m
print smithal(st2, st, 2, 1, 1)
