#include <stdio.h>
#include <stdlib.h>
//obtener entero
int obtent(){
	int num;
	scanf("%d", &num);
	printf("\n");
	getchar();
	return num;
}

//imprimir un vector de char
void imprimirVc(char* vector, int size){	//recibe puntero(contenido) de tipo int llamado vector
  int i;
  for (i = 0; i < size; i++) {
    printf("%c", *(vector+i));		//imprime el contenido del puntero llamado vector+i
  }
  printf("\n");
}

//imprimir un vector de int
void imprimirV(int* vector, int size){	//recibe puntero(contenido) de tipo int llamado vector
  int i;
  for (i = 0; i < size; i++) {
    printf("%d\t", *(vector+i));		//imprime el contenido del puntero llamado vector+i
  }
  printf("\n");
}

//imprimir una matriz
void imprimirM(int **mat, int rows, int cols){
    int i=0;
    int j=0;
  for(i=0; i<rows; i++){    /* Iterate of each row */
        for(j=0; j<cols; j++){  /* In each row, go over each col element  */
            printf("%d ",mat[i][j]); /* Print each row element */
        }
        printf("\n");
    }
}

//llenar String
void fillstr(char* str, int size){		//size: numero de elementos
	int i;
	for (i = 0; i < size; i++) {
		printf("Ingrese elemento: ");

		*(str+i)= getchar();
		getchar();
	}
	printf("\n");
}

//retorna el valor de una posicion indicada en la matriz
int return_ij(int** matriz, int i, int j){

	int* ubRow= *(matriz+(i-1));	//guarda la ubicación de la fila
	int ij= *(ubRow+(j-1));

	printf("%d\n", ij);

	return ij;
	}

//crear matriz con datos que ingresa el usuario
int **makemat(int rows, int cols){

    int **mat = (int **) malloc(sizeof(int *)*rows);
    int i=0,j=0;
    for(i=0; i<rows; i++)
    /* Allocate array, store pointer  */
        mat[i] = (int *) malloc(sizeof(int)*cols);

       for(i=0; i<rows; i++){
           for(j=0; j<cols; j++){
               scanf("%d",&mat[i][j]);
           }
       }
     return mat;
}

//crea una matriz m*n de ceros
int **make0mat(int rows, int cols){

    int **mat = (int **) malloc(sizeof(int *)*rows);
    int i=0,j=0;
    for(i=0; i<rows; i++)
    /* Allocate array, store pointer  */
        mat[i] = (int *) malloc(sizeof(int)*cols);

       for(i=0; i<rows; i++){
           for(j=0; j<cols; j++){
               mat[i][j]=0;
           }
       }
     return mat;
}
//indica el mayor valor arriba de una posicion especifica en una matriz y se le resta el gap penalty respectivo
int maxup(int **mat, int m, int n, int gp){
    int max = 0;
    int i= m-1;
    for(i=m-1; i>=0; i--){
		int v=mat[i][n];
        if(v>max){
          max=v;
            }
        }
    max=max-gp;
	if(max<0){max=0;}
    return max;
}

//indica el mayor valor a la izquierda de una posicion especifica en una matriz y se le resta el gap penalty respectivo
int maxleft(int **mat, int m, int n, int gp){
    int max = 0;
    int j= n-1;
    for(j=n-1; j>=0; j--){
        if(max<mat[m][j]){
         max=mat[m][j];
            }
        }
    max=max-gp;
	if(max<0){max=0;}

    return max;
}

//indica la posicion del maximo valor en la matriz
int* maxmatval(int **mat, int m, int n){
    int max=0;
    int* maxpos=malloc(2);
    int i=0;
    int j=0;
    for(i=0; i<m; i++){
        for(j=0; j<n; j++){
            if(max<=mat[i][j]){
                maxpos[0]=i;
                maxpos[1]=j;
                max=mat[i][j];
                }
            }
        }
    return maxpos;
    }

//indica el valor diagonal anterior a una posicion dada y compara los terminos de dos strings dados, restando o sumando la bonificacion de apareamiento
int diagval(int **mat, int m, int n, int mb, int mp, char* ch1, char* ch2){
	int val=0;
	if(ch1[m-1]==ch2[n-1]){
		val=mat[m-1][n-1]+mb;
		}
	else if(ch1[m-1]!=ch2[n-1]){
		val=mat[m-1][n-1]-mp;
		}
	if(val<0){val=0;}
    return val;
}

//da el maximo valor entre tres numeros
int intmax(int n1, int n2, int n3){
	if(n1>=n2 && n1>=n3 ){ return n1;
    }
    if( n2>=n1 && n2>=n3 ){ return n2;
    }
    if( n3>=n1 && n3>=n2 ){ return n3;
    }
	}

//da el valor maximo entre el maxup, maxleft y el diagval
int hmax(int **mat, int m, int n, int mb, int mp, int gp, char* ch1, char* ch2){
	int left,up,diag, max;
	left = maxleft(mat, m, n, gp);
	up = maxup(mat, m, n, gp);
	diag = diagval(mat, m, n, mb, mp, ch1, ch2);
	max = intmax(left, up, diag);
    return max;
}

int** swmat(int chlen, int mb, int mp, int gp, char* ch1, char* ch2){
   int** m;
   m = make0mat(chlen+1, chlen+1);
   int i=1;
   int j=1;
   for(i=1; i<=chlen; i++){
	   for(j=1;j<=chlen;j++){
		   m[i][j]=hmax(m, i, j, mb, mp, gp, ch1, ch2);
		   }
	   }
	return m;
}

int *hinv(int** mat, int m, int n){
    int up = mat[m-1][n];
    int left = mat[m][n-1];
    int diag = mat[m-1][n-1];
    int* pos=malloc(2);
    if(diag==up && diag==left){
        *pos=m-1;
        *(pos+1)=n-1;
    }
    if(diag==up &&  diag>left){
        *pos=m-1;
        *(pos+1)=n-1;
    }
    if(diag==left &&  diag>up){
        *pos=m-1;
        *(pos+1)=n-1;
    }
    if(diag==up &&  diag<left){
        *pos=m;
        *(pos+1)=n-1;
    }
    if(diag==left &&  diag<up){
        *pos=m-1;
        *(pos+1)=n;
    }
    else if (diag!=up && diag!=left){
        int max = intmax(left, up, diag);
        if(max==up){
            *pos=m-1;
            *(pos+1)=n;
        }
        if(max==left){
            *pos=m;
            *(pos+1)=n-1;
        }
        else if(max==diag){
            *pos=m-1;
            *(pos+1)=n-1;
        }
    }
    return pos;
    }

int **traceback(int** mat, int size){
    int c = 1;
    int* ap = maxmatval(mat, size, size);
    int i=*ap;
    int j=*(ap+1);
    int **tb = (int **) malloc(size*size);
    tb[0] = (int *) malloc(2);
    tb[0]=ap;
    for(c=1; i!=0 && j!=0; c++){
        ap=hinv(mat, i, j);
        i=ap[0];
        j=ap[1];
        //tb = (int **) realloc(tb, c+1);
        tb[c] = (int *) malloc(2);
        tb[c]=ap;
        }
    return tb;
    }

int tbsize(int** mat){
    int c=0;
    int i=0;
    for(c=0; mat[c][0]!=0 && mat[c][1]!=0; c++){
        i++;
        }
    return i+1;
    }

int **invtb(int** tb){
    int size = tbsize(tb);
    int **mat = (int **) malloc(sizeof(int *)*size);
    int i=0;
    for(i=0; i<size; i++){
    mat[i] = (int *) malloc(2);
        }
    int c=0;
    int t=size-1;
    for(c=0; c<size; c++){
        mat[c]=tb[t];
        t=t-1;
        }
    return mat;
    }

char* smithal1(char* chain1, char* chain2, int size, int mb, int mp, int gp){
    int** m = swmat(size, mb, mp, gp, chain1, chain2);
    int** tb = traceback(m, size+1);
    int** intb = invtb(tb);
    char* al = malloc(tbsize(tb)-1);
    int x=0;
    int alp=0;
    for(x=0; x<tbsize(tb)-1; x++){
        int opa[2];
        opa[0] = intb[x][0]+1;
        opa[1] = intb[x][1]+1;
        int opb[2];
        opb[0] = intb[x][0];
        opb[1] = intb[x][1]+1;
        int opc[2];
        opc[0] = intb[x][0]+1;
        opc[1] = intb[x][1];
        if(intb[x+1][0]==opa[0] && intb[x+1][1]==opa[1]){
            al[alp]=chain2[intb[x][1]];
            alp++;
            }
        if(intb[x+1][0]==opb[0] && intb[x+1][1]==opb[1]){
            al[alp]=chain2[intb[x][1]]; alp++;
            }
        if(intb[x+1][0]==opc[0] && intb[x+1][1]==opc[1]){
            al[alp]='-'; alp++;
            }
    }
    return al;
}

char* smithal2(char* chain1, char* chain2, int size, int mb, int mp, int gp){
    int** m = swmat(size, mb, mp, gp, chain1, chain2);
    int** tb = traceback(m, size+1);
    int** intb = invtb(tb);
    char* al = malloc(tbsize(tb)-1);
    int x=0;
    int alp=0;
    for(x=0; x<tbsize(tb)-1; x++){
        int opa[2];
        opa[0] = intb[x][0]+1;
        opa[1] = intb[x][1]+1;
        int opb[2];
        opb[0] = intb[x][0];
        opb[1] = intb[x][1]+1;
        int opc[2];
        opc[0] = intb[x][0]+1;
        opc[1] = intb[x][1];
        if(intb[x+1][0]==opa[0] && intb[x+1][1]==opa[1]){
            al[alp]=chain1[intb[x][0]];
            alp++;
            }
        if(intb[x+1][0]==opb[0] && intb[x+1][1]==opb[1]){
            al[alp]='-'; alp++;
            }
        if(intb[x+1][0]==opc[0] && intb[x+1][1]==opc[1]){
            al[alp]=chain1[intb[x][0]]; alp++;
            }
    }
    return al;
}

void printbestal(char* chain1, char* chain2, int size, int mb, int mp, int gp){
    int** m = swmat(size, mb, mp, gp, chain1, chain2);
    int** tb = traceback(m, size+1);
    imprimirVc(smithal2(chain1, chain2, size, mb, mp, gp), tbsize(tb)-1);
    printf("\n");
    imprimirVc(smithal1(chain1, chain2, size, mb, mp, gp), tbsize(tb)-1);
    }


//cuenta caracteres de un archivo txt hasta el primer salto de línea, sin contar espacios
int file_size(char* fname){

	FILE *pFile;
	pFile = fopen(fname, "r");

	int cont = 0;
	char ct;

	while(ct=fgetc(pFile)!=EOF){
		cont++;
	}

	fclose(pFile);
	return (cont-1);
}

//pasar de un archivo a un arreglo de chars
char* file_to_array(char* fname){

	int size= file_size(fname);	//cantidad de elementos del archivo recibido, hasta el primer salto de línea

	char* arrC = (char*)malloc ( size*sizeof(char) );	//arreglo de chars llamado arrC, cantidad de elementos = size

	int i = 0;

	FILE *pFile;
	pFile = fopen(fname, "r");

	char temp = fgetc(pFile);

	while(temp != 10){		//mientras sea distinto de salto de línea
		if(temp != 32){		//si es distinto de espacio
			*(arrC+i) = temp;
			i = i+1;
		}
		temp = fgetc(pFile);
	}
	fclose(pFile);
	return arrC;
}

//main
int main(int argc, char const *argv[]) {

	//SW recibe 2 cadenas y 3 enteros
	//printf("Ingrese el tamaño del String: ");
	int size= file_size("chain5.txt");		//tamaño strings
	//printf("\%d \n",size);

	//Obtener cadenas
	char* chain1 = file_to_array("chain5.txt");
	char* chain2 = file_to_array("chain6.txt");

	/*
	//llenar cadenas
	char chain1 [size];
	char chain2 [size];

	printf("Cadena 1:\n");
	fillstr(chain1, size);

	printf("Cadena 2:\n");
	fillstr(chain2, size);
	*/

   int** m;
   int** n;
   n = swmat(size, 2, 1, 1, chain1, chain2);
   imprimirM(n, size+1, size+1);
   printf ("Cadena 1:\t");
   imprimirVc(chain1, size);
   printf("\n");
   printf ("Cadena 2:\t");
   imprimirVc(chain2, size);
   char* v = smithal2(chain1, chain2, size, 2, 1, 1);
   //imprimirVc(v, tbsize(m));
   printf("\n");
   printbestal(chain1, chain2, size, 2, 1, 1);
 //  imprimirVc(v, tbsize(m), 2);
   //printf("%d", tbsize(m));
   printf("\n");
  return 0;
}
